﻿namespace SEDTFLU
{
    partial class Attack
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Attack));
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SelectPanel = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.bannerGrabber1 = new SEDTFLU.BannerGrabber();
            this.synFlood1 = new SEDTFLU.SynFlood();
            this.search1 = new SEDTFLU.Search();
            this.record1 = new SEDTFLU.Record();
            this.sqlinject1 = new SEDTFLU.sqlinject();
            this.SuspendLayout();
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(23, 266);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(190, 52);
            this.button5.TabIndex = 9;
            this.button5.Text = "Banner Grabber";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(23, 54);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(190, 52);
            this.button4.TabIndex = 8;
            this.button4.Text = "Search";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(23, 107);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(190, 52);
            this.button3.TabIndex = 7;
            this.button3.Text = "Social Lookup";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(23, 1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(190, 52);
            this.button2.TabIndex = 6;
            this.button2.Text = "Attack";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(23, 213);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(190, 52);
            this.button1.TabIndex = 5;
            this.button1.Text = "Port Scanner";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // SelectPanel
            // 
            this.SelectPanel.BackColor = System.Drawing.Color.Maroon;
            this.SelectPanel.Location = new System.Drawing.Point(1, 1);
            this.SelectPanel.Name = "SelectPanel";
            this.SelectPanel.Size = new System.Drawing.Size(21, 52);
            this.SelectPanel.TabIndex = 10;
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(23, 319);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(190, 52);
            this.button6.TabIndex = 11;
            this.button6.Text = "Scanner";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(23, 160);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(190, 52);
            this.button7.TabIndex = 15;
            this.button7.Text = "SYN FLood";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(23, 372);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(190, 52);
            this.button8.TabIndex = 17;
            this.button8.Text = "Reverse Shell";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(23, 478);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(190, 52);
            this.button9.TabIndex = 18;
            this.button9.Text = "Password Cracker";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(23, 531);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(190, 52);
            this.button10.TabIndex = 19;
            this.button10.Text = "Vulnerability Scanner";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(23, 425);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(190, 52);
            this.button11.TabIndex = 20;
            this.button11.Text = "SQL Injection";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // bannerGrabber1
            // 
            this.bannerGrabber1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.bannerGrabber1.Location = new System.Drawing.Point(215, 1);
            this.bannerGrabber1.Name = "bannerGrabber1";
            this.bannerGrabber1.Size = new System.Drawing.Size(584, 600);
            this.bannerGrabber1.TabIndex = 16;
            // 
            // synFlood1
            // 
            this.synFlood1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.synFlood1.Location = new System.Drawing.Point(215, 1);
            this.synFlood1.Name = "synFlood1";
            this.synFlood1.Size = new System.Drawing.Size(584, 600);
            this.synFlood1.TabIndex = 14;
            // 
            // search1
            // 
            this.search1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.search1.Location = new System.Drawing.Point(215, 1);
            this.search1.MaximumSize = new System.Drawing.Size(584, 600);
            this.search1.MinimumSize = new System.Drawing.Size(584, 600);
            this.search1.Name = "search1";
            this.search1.Size = new System.Drawing.Size(584, 600);
            this.search1.TabIndex = 13;
            // 
            // record1
            // 
            this.record1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.record1.Location = new System.Drawing.Point(215, 1);
            this.record1.MaximumSize = new System.Drawing.Size(584, 600);
            this.record1.MinimumSize = new System.Drawing.Size(584, 600);
            this.record1.Name = "record1";
            this.record1.Size = new System.Drawing.Size(584, 600);
            this.record1.TabIndex = 12;
            // 
            // sqlinject1
            // 
            this.sqlinject1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.sqlinject1.Location = new System.Drawing.Point(215, 1);
            this.sqlinject1.Name = "sqlinject1";
            this.sqlinject1.Size = new System.Drawing.Size(584, 600);
            this.sqlinject1.TabIndex = 21;
            // 
            // Attack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(61)))), ((int)(((byte)(61)))));
            this.ClientSize = new System.Drawing.Size(800, 602);
            this.Controls.Add(this.sqlinject1);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.bannerGrabber1);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.synFlood1);
            this.Controls.Add(this.search1);
            this.Controls.Add(this.record1);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.SelectPanel);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(816, 641);
            this.MinimumSize = new System.Drawing.Size(816, 641);
            this.Name = "Attack";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Attack";
            this.Load += new System.EventHandler(this.Attack_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel SelectPanel;
        private System.Windows.Forms.Button button6;
        private Record record1;
        private Search search1;
        private SynFlood synFlood1;
        private System.Windows.Forms.Button button7;
        private BannerGrabber bannerGrabber1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private sqlinject sqlinject1;
    }
}